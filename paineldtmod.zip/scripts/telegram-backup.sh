#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/paineldtmod"
BRAND="@nandoslayer"
CONFIG_FILE="${APP_DIR}/telegram.conf"
DATA_DIR="${APP_DIR}/data"
BACKUP_DIR="${DATA_DIR}/backups"
DB_FILE="${DATA_DIR}/database.db"
ENV_FILE="${APP_DIR}/.env"
DOMAIN_FILE="/etc/paineldtmod.conf"
NGINX_FILE="/etc/nginx/sites-available/paineldtmod.conf"
SCHEDULE_FILE="/etc/paineldtmod-backup.conf"
BACKUP_TIMER="paineldtmod-backup.timer"
BACKUP_SERVICE="paineldtmod-backup.service"
API=""

erro() { echo "Erro: $*" >&2; return 1; }
carregar_config() {
  [[ -r "$CONFIG_FILE" ]] || erro "Telegram ainda não foi configurado."
  # shellcheck disable=SC1090
  source "$CONFIG_FILE"
  [[ -n "${TELEGRAM_BOT_TOKEN:-}" && -n "${TELEGRAM_CHAT_ID:-}" ]] || erro "configuração do Telegram incompleta."
  API="https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}"
}
telegram() { curl -fsS "$API/$1" "${@:2}"; }
MENU_JSON='{"inline_keyboard":[[{"text":"📦 Fazer backup","callback_data":"backup"},{"text":"📊 Contadores das tabelas","callback_data":"contadores"}],[{"text":"⏱️ Backup automático","callback_data":"automatico"}],[{"text":"♻️ Restaurar backup","callback_data":"restaurar"}]]}'
MENU_VOLTAR_JSON='{"inline_keyboard":[[{"text":"⬅️ Menu principal","callback_data":"menu"}]]}'
MENU_AUTOMATICO_JSON='{"inline_keyboard":[[{"text":"1 hora","callback_data":"auto_1h"},{"text":"3 horas","callback_data":"auto_3h"}],[{"text":"6 horas","callback_data":"auto_6h"},{"text":"12 horas","callback_data":"auto_12h"}],[{"text":"⛔ Desativar","callback_data":"auto_off"}],[{"text":"⬅️ Menu principal","callback_data":"menu"}]]}'
enviar_texto() { telegram sendMessage --data-urlencode "chat_id=${TELEGRAM_CHAT_ID}" --data-urlencode "text=$1" >/dev/null; }
enviar_menu() { telegram sendMessage --data-urlencode "chat_id=${TELEGRAM_CHAT_ID}" --data-urlencode "text=$1" --data-urlencode "reply_markup=${MENU_JSON}" >/dev/null; }
responder_botao() { telegram answerCallbackQuery --data-urlencode "callback_query_id=$1" >/dev/null; }

criar_backup() {
  mkdir -p "$BACKUP_DIR"
  local stamp arquivo temp_db
  stamp="$(date +%Y%m%d-%H%M%S)"
  arquivo="${BACKUP_DIR}/paineldtmod-${stamp}.tar.gz"
  temp_db="$(mktemp)"
  trap 'rm -f "$temp_db"' RETURN
  [[ -f "$DB_FILE" ]] || erro "banco de dados não encontrado."
  [[ -f "$ENV_FILE" ]] || erro "arquivo .env não encontrado."
  sqlite3 "$DB_FILE" ".backup '$temp_db'"
  local pacote_temp
  pacote_temp="$(mktemp -d)"
  cp "$temp_db" "$pacote_temp/database.db"
  cp "$ENV_FILE" "$pacote_temp/.env"
  [[ -f "$DOMAIN_FILE" ]] && cp "$DOMAIN_FILE" "$pacote_temp/paineldtmod.conf"
  [[ -f "$CONFIG_FILE" ]] && cp "$CONFIG_FILE" "$pacote_temp/telegram.conf"
  [[ -f "$NGINX_FILE" ]] && cp "$NGINX_FILE" "$pacote_temp/nginx.conf"
  tar -czf "$arquivo" -C "$pacote_temp" .
  rm -rf "$pacote_temp"
  mapfile -t antigos < <(ls -1t "$BACKUP_DIR"/paineldtmod-*.tar.gz 2>/dev/null | tail -n +31)
  ((${#antigos[@]} == 0)) || rm -f "${antigos[@]}"
  echo "$arquivo"
}

enviar_backup() {
  carregar_config
  local arquivo legenda="${1:-Backup do Painel DTunnelMod | ${BRAND}}"
  arquivo="$(criar_backup)"
  telegram sendDocument -F "chat_id=${TELEGRAM_CHAT_ID}" -F "document=@${arquivo}" -F "caption=${legenda}" >/dev/null
  echo "Backup enviado: $arquivo"
}

configurar_agendamento() {
  local intervalo="$1"
  case "$intervalo" in
    1h|3h|6h|12h) ;;
    *) erro "intervalo de backup inválido." ;;
  esac
  cat > "$SCHEDULE_FILE" <<CFG
BACKUP_INTERVAL='${intervalo}'
CFG
  chmod 0644 "$SCHEDULE_FILE"
  cat > "/etc/systemd/system/${BACKUP_TIMER}" <<UNIT
[Unit]
Description=Agendamento de backup do Painel DTunnelMod - ${BRAND}

[Timer]
OnActiveSec=${intervalo}
OnUnitActiveSec=${intervalo}
Persistent=true
Unit=${BACKUP_SERVICE}

[Install]
WantedBy=timers.target
UNIT
  systemctl daemon-reload
  systemctl enable --now "$BACKUP_TIMER"
}

desativar_agendamento() {
  systemctl disable --now "$BACKUP_TIMER" 2>/dev/null || true
  rm -f "/etc/systemd/system/${BACKUP_TIMER}" "$SCHEDULE_FILE"
  systemctl daemon-reload
}

restaurar_backup() {
  local arquivo="${1:-}"
  [[ -f "$arquivo" ]] || erro "informe um arquivo .tar.gz válido."
  local temp_dir
  temp_dir="$(mktemp -d)"
  trap 'rm -rf "$temp_dir"' RETURN
  tar -xzf "$arquivo" -C "$temp_dir"
  [[ -s "$temp_dir/database.db" && -s "$temp_dir/.env" ]] || erro "backup inválido: database.db ou .env ausente."
  systemctl stop paineldtmod
  cp "$temp_dir/database.db" "$DB_FILE"
  cp "$temp_dir/.env" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  if [[ -f "$temp_dir/paineldtmod.conf" ]]; then
    cp "$temp_dir/paineldtmod.conf" "$DOMAIN_FILE"
  fi
  if [[ -f "$temp_dir/telegram.conf" ]]; then
    cp "$temp_dir/telegram.conf" "$CONFIG_FILE"
    chmod 600 "$CONFIG_FILE"
  fi
  if [[ -f "$temp_dir/nginx.conf" ]]; then
    nginx_backup="$(mktemp)"
    [[ -f "$NGINX_FILE" ]] && cp "$NGINX_FILE" "$nginx_backup"
    cp "$temp_dir/nginx.conf" "$NGINX_FILE"
    if nginx -t && systemctl reload nginx; then
      rm -f "$nginx_backup"
    else
      if [[ -s "$nginx_backup" ]]; then
        cp "$nginx_backup" "$NGINX_FILE"
      else
        rm -f "$NGINX_FILE"
      fi
      rm -f "$nginx_backup"
      echo "Aviso: configuração antiga do Nginx mantida." >&2
    fi
  fi
  systemctl start paineldtmod
  echo "Backup restaurado e painel iniciado."
}

mostrar_contadores() {
  local contadores
  contadores="$(cd "$APP_DIR" && node scripts/contar-tabelas.js)"
  telegram sendMessage --data-urlencode "chat_id=${TELEGRAM_CHAT_ID}" --data-urlencode "text=$contadores" --data-urlencode "reply_markup=${MENU_VOLTAR_JSON}" >/dev/null
}

processar_comando() {
  local chat_id="$1" texto="$2"
  [[ "$chat_id" == "$TELEGRAM_CHAT_ID" ]] || return 0
  case "$texto" in
    /start) enviar_menu "$(printf 'Painel DTunnelMod | %s\n\nEscolha uma opção:' "$BRAND")" ;;
  esac
}

processar_botao() {
  local chat_id="$1" callback_id="$2" acao="$3"
  [[ "$chat_id" == "$TELEGRAM_CHAT_ID" ]] || return 0
  responder_botao "$callback_id"
  case "$acao" in
    menu) enviar_menu "$(printf 'Painel DTunnelMod | %s\n\nEscolha uma opção:' "$BRAND")" ;;
    automatico)
      telegram sendMessage --data-urlencode "chat_id=${TELEGRAM_CHAT_ID}" --data-urlencode "text=Escolha de quanto em quanto tempo o backup será enviado:" --data-urlencode "reply_markup=${MENU_AUTOMATICO_JSON}" >/dev/null
      ;;
    backup)
      if arquivo_backup="$(enviar_backup)"; then
        mensagem_backup="$(printf 'Backup criado e enviado com sucesso.\n\n%s' "$arquivo_backup")"
        enviar_menu "$mensagem_backup"
      else
        enviar_menu "Não foi possível criar o backup. Verifique os logs do serviço."
      fi
      ;;
    auto_1h|auto_3h|auto_6h|auto_12h)
      intervalo="${acao#auto_}"
      if ! configurar_agendamento "$intervalo"; then
        enviar_menu "Não foi possível configurar o backup automático."
      elif enviar_backup "Backup automático ativado" >/dev/null; then
        enviar_menu "Backup automático ativado a cada ${intervalo}. O primeiro backup já foi enviado."
      else
        enviar_menu "Agendamento ativado a cada ${intervalo}, mas o primeiro backup não pôde ser enviado."
      fi
      ;;
    auto_off)
      desativar_agendamento
      enviar_menu "Backup automático desativado."
      ;;
    contadores) mostrar_contadores ;;
    restaurar)
      touch "${DATA_DIR}/telegram-aguardando-restauro"
      telegram sendMessage --data-urlencode "chat_id=${TELEGRAM_CHAT_ID}" --data-urlencode "text=Envie agora o arquivo .tar.gz do backup. O painel será reiniciado durante a restauração." --data-urlencode "reply_markup=${MENU_VOLTAR_JSON}" >/dev/null
      ;;
  esac
}

modo_bot() {
  carregar_config
  local offset=0 updates update id chat_id texto file_id file_path download_file callback_id callback_data
  [[ -f "${DATA_DIR}/telegram.offset" ]] && offset="$(cat "${DATA_DIR}/telegram.offset")"
  while true; do
    updates="$(telegram getUpdates --get --data-urlencode "offset=$offset" --data-urlencode timeout=25)" || { sleep 5; continue; }
    while IFS= read -r update; do
      [[ -n "$update" ]] || continue
      id="$(jq -r '.update_id' <<< "$update")"
      offset=$((id + 1)); echo "$offset" > "${DATA_DIR}/telegram.offset"
      chat_id="$(jq -r '.message.chat.id // empty' <<< "$update")"
      texto="$(jq -r '.message.text // empty' <<< "$update")"
      callback_id="$(jq -r '.callback_query.id // empty' <<< "$update")"
      callback_data="$(jq -r '.callback_query.data // empty' <<< "$update")"
      if [[ -n "$callback_id" ]]; then
        chat_id="$(jq -r '.callback_query.message.chat.id // empty' <<< "$update")"
        processar_botao "$chat_id" "$callback_id" "$callback_data"
        continue
      fi
      if [[ -n "$texto" ]]; then processar_comando "$chat_id" "$texto"; continue; fi
      if [[ -f "${DATA_DIR}/telegram-aguardando-restauro" ]]; then
        file_id="$(jq -r '.message.document.file_id // empty' <<< "$update")"
        [[ "$chat_id" == "$TELEGRAM_CHAT_ID" && -n "$file_id" ]] || continue
        file_path="$(telegram getFile --get --data-urlencode "file_id=$file_id" | jq -r '.result.file_path')"
        download_file="$(mktemp --suffix=.tar.gz)"
        curl -fsS "https://api.telegram.org/file/bot${TELEGRAM_BOT_TOKEN}/${file_path}" -o "$download_file"
        rm -f "${DATA_DIR}/telegram-aguardando-restauro"
        if restaurar_backup "$download_file"; then enviar_menu "Backup restaurado com sucesso."; else enviar_menu "Falha ao restaurar o backup."; fi
        rm -f "$download_file"
      fi
    done < <(jq -c '.result[]' <<< "$updates")
  done
}

case "${1:-}" in
  backup) enviar_backup ;;
  scheduled) enviar_backup "Backup automático do Painel DTunnelMod | ${BRAND}" >/dev/null ;;
  restaurar) restaurar_backup "${2:-}" ;;
  bot) modo_bot ;;
  *) echo "Uso: telegram-backup.sh {backup|restaurar ARQUIVO|bot}"; exit 1 ;;
esac
