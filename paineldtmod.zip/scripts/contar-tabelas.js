require('dotenv/config');

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const tabelas = [
  ['users', () => prisma.user.count()],
  ['cdn', () => prisma.cdn.count()],
  ['categories', () => prisma.category.count()],
  ['app_configs', () => prisma.appConfig.count()],
  ['app_texts', () => prisma.appText.count()],
  ['app_layouts', () => prisma.appLayout.count()],
  ['app_layout_storages', () => prisma.appLayoutStorage.count()],
];

async function main() {
  const resultados = await Promise.all(
    tabelas.map(async ([tabela, contar]) => [tabela, await contar()]),
  );

  console.log('Quantidade de registros por tabela:');
  for (const [tabela, quantidade] of resultados) {
    console.log(`${tabela}: ${quantidade}`);
  }
}

main()
  .catch((erro) => {
    console.error(`Não foi possível consultar o banco: ${erro.message}`);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
