-- Adds support for the XRAY connection mode
ALTER TABLE "app_configs" ADD COLUMN "auth_xray_uuid" TEXT;
ALTER TABLE "app_configs" ADD COLUMN "config_xray" TEXT;
