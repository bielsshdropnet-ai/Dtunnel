import { z } from 'zod';
import Authentication from '../../../middlewares/authentication';
import { FastifyReply, FastifyRequest, RouteOptions } from 'fastify';

const querySchema = z.object({
  url: z.string().url(),
});

export default {
  url: '/configs/check_url',
  method: 'GET',
  onRequest: [Authentication.user],
  handler: async (req: FastifyRequest, reply: FastifyReply) => {
    const parsed = querySchema.safeParse(req.query);

    if (!parsed.success) {
      return reply.status(400).send({ status: 400, message: 'URL inválida.' });
    }

    const { url } = parsed.data;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);

    try {
      const response = await fetch(url, { signal: controller.signal });
      clearTimeout(timeout);

      return reply.send({
        status: 200,
        data: { ok: response.ok, http_status: response.status },
      });
    } catch (err) {
      clearTimeout(timeout);
      const message = err instanceof Error ? err.message : 'Falha ao conectar na URL.';

      return reply.send({
        status: 200,
        data: { ok: false, http_status: null, error: message },
      });
    }
  },
} as RouteOptions;
